
package estruturadados;


public class Site {
    public String nome;
    public String url;
    
    public Site()
    {
    
    }
    
    public Site(String _nome, String _url)
    {
        nome = _nome;
        url = _url;
    }
}
