
package estruturadados;


public class EstruturaDados {

   
    public static void main(String[] args) {
      Favoritos fav = new Favoritos();
      
      fav.executa();
    }
    
}
